//
//  Ship.cpp
//  GameEngine
//
//  Created by David Lively on 2/22/16.
//  Copyright © 2016 David Lively. All rights reserved.
//

#include "Common.h"
#include "Ship.h"
#include "Mesh.h"
#include "Game.h"
#include "Camera.h"

#include <vector>
#include <cmath>

using namespace std;

bool Ship::OnInitialize()
{
    auto& mesh = Create<Mesh>("ship-mesh");
    
    vector<float> vertices =
    {
        0,0.5f, 0
        ,
        1/3.f, -0.5f, 0
        ,
        -1/3.f, -0.5f, 0
		,
		0, -.5f, 1/3.f
    };
    
    vector<GLushort> indices = {
		0,1,2
		,
		0,1,3
		,
		0,3,2
		,
		1,2,3
	};
    
    mesh.Initialize(vertices, indices);
    
    m_mesh = &mesh;

	bounds.setBounds(Vector3(0.f, 0.f, 0.f), 0.5f);

    auto& material = Create<class Material>("ship-material");
    m_material = &material;
    
    mesh.Material = &material;
    material.FillType = PolygonMode::Fill;
    
    drag = 0.003f;
	m_meshColor.X = 1.0f; m_meshColor.Y = 0.0f, m_meshColor.Z = 1.0f, m_meshColor.W = 1.0f;

    return material.Build("Shaders/primitive");

}

void Ship::OnUpdate(const GameTime& time)
{
	GLFWwindow* window = Game::Instance().Window();

	if (glfwGetKey(window, GLFW_KEY_LEFT)) {
		Transform.Rotation.Z -= 3.0f * time.ElapsedSeconds();
	}

	if (glfwGetKey(window, GLFW_KEY_RIGHT)) {
		Transform.Rotation.Z += 3.0f * time.ElapsedSeconds();
	}

	if (glfwGetKey(window, GLFW_KEY_UP)) {
		
		Matrix t = Transform.GetMatrix();

		pushTranslation(t.m10 * 0.1f, t.m11 * 0.1f, 0.0f, time);

	}

	if (glfwGetKey(window, GLFW_KEY_DOWN)) {

		Matrix t = Transform.GetMatrix();

		pushTranslation(t.m10 * -0.1f, t.m11 * -0.1f, 0.0f, time);

	}

	if (glfwGetKey(window, GLFW_KEY_0)) {
		Log::Info << "Break";
	}

	WorldEntity::OnUpdate(time);
}



void Ship::OnRender(const GameTime& time)
{
    
    auto& cam = Game::Camera;
    

    m_material->Bind();
    m_material->SetUniform("World", Transform.GetMatrix());
    m_material->SetUniform("View",cam.GetViewMatrix());
    m_material->SetUniform("Projection",cam.GetProjectionMatrix());
	m_material->SetUniform("meshColor", m_meshColor);
}


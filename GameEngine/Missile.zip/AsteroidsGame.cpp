//
//  SimpleGame.cpp
//  GameEngine
//
//  Created by David Lively on 2/3/16.
//
//	Modified by Mitchel Pederson
//  Copyright © 2016 David Lively. All rights reserved.
//

#include <vector>
#include <iostream>

using namespace std;

#include "AsteroidsGame.h"
#include "Mesh.h"
#include "Material.h"
#include "Files.h"
#include "InputHandler.h"
#include "Grid.h"
#include "Common.h"
#include "Asteroid.h"

#include <vector>
#include <cmath>
#include <random>

using namespace std;

bool AsteroidsGame::OnCreateScene()
{
    //m_ship = Create<Ship>("ship");

	srand((int) glfwGetTime() * 1000);
   
    Create<InputHandler>("asteroids-input");
	Create<Grid>("grid");

	m_asteroids.push_back(&Create<Asteroid>("asteroid1"));
	m_asteroids.push_back(&Create<Asteroid>("asteroid2"));
	m_asteroids.push_back(&Create<Asteroid>("asteroid3"));
	m_asteroids.push_back(&Create<Asteroid>("asteroid4"));
	m_asteroids.push_back(&Create<Asteroid>("asteroid5"));
	m_asteroids.push_back(&Create<Asteroid>("asteroid6"));

	m_missiles.push_back(&Create<Missile>("missile1"));
	m_missiles.push_back(&Create<Missile>("missile2"));
	m_missiles.push_back(&Create<Missile>("missile3"));
	m_missiles.push_back(&Create<Missile>("missile4"));
	m_missiles.push_back(&Create<Missile>("missile5"));
	m_missiles.push_back(&Create<Missile>("missile6"));

	for (int i = 0; i < m_missiles.size(); i++) {
		m_missiles[i]->Deactivate();
	}

	//a1.pushTranslation(0.1f, 0, 0, Time);
	//a2.pushTranslation(0, 0.1f, 0, Time);

	auto& cam = Game::Camera;
	cam.Transform.Translation.Z = 25.0f;

	// Rotating the camera causes the bounding to break
	//cam.Transform.Rotation.Z = TO_RADIANS(20.0f);

    return true;
    
}

void AsteroidsGame::OnUpdate(const GameTime& time)
{

	if (glfwGetKey(Window(), GLFW_KEY_W)) {
		Game::Camera.Transform.Rotation.X += 0.4f * time.ElapsedSeconds();
	}
	if (glfwGetKey(Window(), GLFW_KEY_S)) {
		Game::Camera.Transform.Rotation.X -= 0.4f * time.ElapsedSeconds();
	}

	if (glfwGetKey(Window(), GLFW_KEY_A)) {
		Game::Camera.Transform.Rotation.Z += 0.4f * time.ElapsedSeconds();
	}
	if (glfwGetKey(Window(), GLFW_KEY_D)) {
		Game::Camera.Transform.Rotation.Z -= 0.4f * time.ElapsedSeconds();
	}
	if (glfwGetKey(Window(), GLFW_KEY_Q)) {
		Game::Camera.Transform.Rotation.Y += 0.4f * time.ElapsedSeconds();
	}
	if (glfwGetKey(Window(), GLFW_KEY_E)) {
		Game::Camera.Transform.Rotation.Y -= 0.4f * time.ElapsedSeconds();
	}

	if (glfwGetKey(Window(), GLFW_KEY_SPACE)) {

		fire(time);

	}

	Game::Camera.updateNormals(time);

	collisionDetection();
}

void AsteroidsGame::collisionDetection() {
	
	for (int i = 0; i < m_asteroids.size(); i++) {

			// First check if the ship collided with an asteroid
		if (m_asteroids[i]->bounds.intersects(m_ship.bounds)) {
			m_ship.sendToOrigin();
		}

			// Now check if any missiles have hit the asteroids.
		for (int j = 0; j < m_missiles.size(); j++) {

			// If the missile is active AND the missile is intersecting the asteroid
			if (m_missiles[j]->isActive() && m_asteroids[i]->bounds.intersects(m_missiles[j]->bounds)) {
				Log::Info << "Asteroid hit!\n";
				m_missiles[j]->Deactivate();
			}
		}
	}
}


void AsteroidsGame::fire(const GameTime& time) {

	Missile* missile = getInactiveMissile();

		// If getInactiveMissile returned a missile, and if it has been at least .4 secs since last shot
	if (nullptr != missile && (time.TotalSeconds() - m_lastShotTime) > 0.4f) {
		Log::Info << "Fire!\n";

		missile->Activate(m_ship, time);

		m_lastShotTime = time.TotalSeconds();

	}
}

Missile* AsteroidsGame::getInactiveMissile() {
	for (int i = 0; i < m_missiles.size(); i++) {
		if (!m_missiles[i]->isActive()) {
			return m_missiles[i];
		}
	}

	return nullptr;

}

